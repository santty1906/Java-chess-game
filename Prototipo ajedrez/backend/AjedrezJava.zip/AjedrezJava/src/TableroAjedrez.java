import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class TableroAjedrez extends JFrame {

    private final int filas = 8;
    private final int columnas = 8;
    private JLabel[][] celdas = new JLabel[filas][columnas];
    private String[][] piezas = new String[filas][columnas]; // Guarda el nombre de la imagen en cada celda

    private int filaSeleccionada = -1;
    private int colSeleccionada = -1;

    public TableroAjedrez() {
        setTitle("Tablero de Ajedrez");
        setSize(650, 650);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel tablero = new JPanel(new GridLayout(filas, columnas));
        boolean blanco = true;

        for (int fila = 0; fila < filas; fila++) {
            for (int col = 0; col < columnas; col++) {
                JPanel panelCasilla = new JPanel(new BorderLayout());
                JLabel etiqueta = new JLabel();
                etiqueta.setHorizontalAlignment(JLabel.CENTER);
                etiqueta.setVerticalAlignment(JLabel.CENTER);

                panelCasilla.setBackground(blanco ? new Color(240, 217, 181) : new Color(181, 136, 99));
                panelCasilla.add(etiqueta);
                tablero.add(panelCasilla);

                celdas[fila][col] = etiqueta;

                final int f = fila;
                final int c = col;

                etiqueta.addMouseListener(new MouseAdapter() {
                    @Override
                    public void mouseClicked(MouseEvent e) {
                        manejarClick(f, c);
                    }
                });

                blanco = !blanco;
            }
            blanco = !blanco;
        }

        add(tablero);
        colocarTodasLasPiezas();
    }

    private void manejarClick(int fila, int col) {
        if (filaSeleccionada == -1) {
            // Primer clic: seleccionar pieza
            if (piezas[fila][col] != null) {
                filaSeleccionada = fila;
                colSeleccionada = col;
                celdas[fila][col].setBorder(BorderFactory.createLineBorder(Color.RED, 2));
            }
        } else {
            // Segundo clic: mover pieza
            moverPieza(filaSeleccionada, colSeleccionada, fila, col);
            celdas[filaSeleccionada][colSeleccionada].setBorder(null);
            filaSeleccionada = -1;
            colSeleccionada = -1;
        }
    }

    private void moverPieza(int filaOrigen, int colOrigen, int filaDestino, int colDestino) {
        String imagen = piezas[filaOrigen][colOrigen];
        piezas[filaDestino][colDestino] = imagen;
        piezas[filaOrigen][colOrigen] = null;

        celdas[filaDestino][colDestino].setIcon(celdas[filaOrigen][colOrigen].getIcon());
        celdas[filaOrigen][colOrigen].setIcon(null);
    }

    private void colocarTodasLasPiezas() {
        // Blancas
        colocar("resources/torre_blanca.png", 7, 0);
        colocar("resources/caballo_blanca.png", 7, 1);
        colocar("resources/alfil_blanca.png", 7, 2);
        colocar("resources/reina_blanca.png", 7, 3);
        colocar("resources/rey_blanca.png", 7, 4);
        colocar("resources/alfil_blanca.png", 7, 5);
        colocar("resources/caballo_blanca.png", 7, 6);
        colocar("resources/torre_blanca.png", 7, 7);
        for (int i = 0; i < columnas; i++) {
            colocar("resources/peon_blanco.png", 6, i);
        }

        // Negras
        colocar("resources/torre_negra.png", 0, 0);
        colocar("resources/caballo_negra.png", 0, 1);
        colocar("resources/alfil_negra.png", 0, 2);
        colocar("resources/reina_negra.png", 0, 3);
        colocar("resources/rey_negra.png", 0, 4);
        colocar("resources/alfil_negra.png", 0, 5);
        colocar("resources/caballo_negra.png", 0, 6);
        colocar("resources/torre_negra.png", 0, 7);
        for (int i = 0; i < columnas; i++) {
            colocar("resources/peon_negro.png", 1, i);
        }
    }

    private void colocar(String nombreImagen, int fila, int columna) {
        ImageIcon icono = new ImageIcon(nombreImagen);
        Image imagen = icono.getImage().getScaledInstance(60, 60, Image.SCALE_SMOOTH);
        celdas[fila][columna].setIcon(new ImageIcon(imagen));
        piezas[fila][columna] = nombreImagen;
    }
}